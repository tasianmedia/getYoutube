--------------------
Extra: getYoutube
--------------------
Version: 1.0.0-pl
Released: April 14, 2014
Since: February 25, 2014
Author: David Pede <dev@tasianmedia.com> <https://twitter.com/davepede>
Copyright: (C) 2014 David Pede. All rights reserved. <dev@tasianmedia.com>

A simple video retrieval Snippet for MODX Revolution.

Official Documentation:
http://rtfm.modx.com/extras/revo/getyoutube

GitHub Repository:
http://github.com/tasianmedia/getYoutube

Bugs & Feature Requests:
http://github.com/tasianmedia/getYoutube/issues

Please Note:
getYoutube is not associated with or endorsed by YouTube, LLC.

License:
Released under the GNU General Public License; either version 2 of the License, or (at your option) any later version.
http://www.gnu.org/licenses/gpl.html